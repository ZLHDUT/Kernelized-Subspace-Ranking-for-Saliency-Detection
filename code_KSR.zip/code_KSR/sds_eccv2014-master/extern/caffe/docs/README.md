To generate stuff you can paste in an .md page from an IPython notebook, run

    ipython nbconvert --to markdown <notebook_file>
